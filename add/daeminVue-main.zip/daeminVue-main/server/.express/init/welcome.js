import { PORT } from "./server"

console.log("")
// log node-env
console.log("- NODE_ENV=" + process.env.NODE_ENV)
// log port
console.log("- PORT=" + PORT)
console.log("")
