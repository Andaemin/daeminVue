export default {
  env: {
    production: ".env",
    development: ".env.development",
  },
};
