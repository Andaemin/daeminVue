<script setup>
// import HeaderNav from './components/layouts/HeaderNav.vue'
</script>

<template>
  <v-app>
    <router-view />
  </v-app>
</template>

<style scoped></style>
