// import { defineStore } from 'pinia'
// import { ref } from 'vue'

// export const useResisterStore = defineStore('user', () => {
//   const user
// })
// <section id="banner" class="banner-section section-animate">
//   <div class="banner-container">
//     <div class="banner-background">
//       <div class="coffee-beans">
//         <div class="bean bean-1"></div>
//         <div class="bean bean-2"></div>
//         <div class="bean bean-3"></div>
//         <div class="bean bean-4"></div>
//         <div class="bean bean-5"></div>
//       </div>
//     </div>

//     <div class="banner-content">
//       <div class="banner-text">
//         <h2 class="banner-title">Always Following Coffee</h2>
//         <p class="banner-subtitle">언제 어디서나 커피와 함께하는 CaFverse</p>
//         <p class="banner-description">
//           커피라는 창조물이 만들어낸 무한한 세계에서<br />
//           당신만의 이야기를 시작해보세요
//         </p>
//       </div>

//       <div class="banner-visual">
//         <div class="coffee-cup">
//           <div class="cup-body"></div>
//           <div class="cup-handle"></div>
//           <div class="coffee-steam">
//             <div class="steam steam-1"></div>
//             <div class="steam steam-2"></div>
//             <div class="steam steam-3"></div>
//           </div>
//         </div>
//         <img :src="sproutSmile" alt="SproutCreature" class="banner-mascot" />
//       </div>
//     </div>
//   </div>
// </section>

// <!-- 개선된 Footer -->
// <footer id="footer" class="footer-section">
//   <div class="container">
//     <div class="footer-content">
//       <div class="footer-brand">
//         <h3 class="footer-title">CaFverse</h3>
//         <p class="footer-tagline">커피를 쫓는 모든 이들의 공간</p>
//       </div>

//       <div class="footer-info">
//         <div class="footer-column">
//           <h4>개발 정보</h4>
//           <p>명지전문대학 정보통신공학과</p>
//           <p>제작자: 안대민 (2025702042)</p>
//         </div>

//         <div class="footer-column">
//           <h4>연락처</h4>
//           <a href="https://instagram.com/nayeony" target="_blank" class="instagram-link">
//             @nayeony
//           </a>
//         </div>
//       </div>

//       <div class="footer-mascot">
//         <img :src="sproutCreature" alt="SproutCreature" class="footer-sprout" />
//       </div>
//     </div>

//     <div class="footer-bottom">
//       <p>&copy; 2025 CaFverse. All rights reserved. Made with ❤️ for coffee lovers.</p>
//     </div>
//   </div>
// </footer>
