<script setup></script>

<template>
  <v-app></v-app>
</template>
