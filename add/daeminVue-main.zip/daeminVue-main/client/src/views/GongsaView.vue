<script setup>
import sproutMulumm from '../assets/sprout_mulumm.png'
</script>
<template>
  <v-container class="d-flex flex-column justify-center align-cente h-screen fill-height">
    <v-img :src="sproutMulumm" width="190" max-height="190" class="ma-2" />
    <h1 style="font-size: 38px">👷🏿‍♂️ 공사중입니다.</h1>
    <v-card-subtitle style="font-size: 20px"
      >어차피 볼 거 없으니 개짓거리 말고 나가십쇼</v-card-subtitle
    >
  </v-container>
</template>
