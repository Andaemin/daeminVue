<script setup>
import HeaderNav from '@/components/layouts/HeaderNav.vue'
</script>

<template>
  <HeaderNav />
  <v-container class="d-flex justify-center h-screen w-100 bg-caf-navy ma-0 fill-height" fluid>
    <h1>포럼 메인임</h1>
  </v-container>
</template>
