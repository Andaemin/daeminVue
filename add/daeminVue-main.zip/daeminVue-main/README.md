# Project CaFverse
<br>
<img src="https://github.com/user-attachments/assets/0e762b63-c818-4dba-a198-f71585ff6ecf" width="150" height="150">
+
<img src="https://github.com/user-attachments/assets/bfc6f51b-a4ba-4227-8817-9ca5ca39c1d6" width="150" height="150">


<br><br>

This template should help get you started developing with Vue 3 in Vite. <br>
#### " 이거 비트 썻으니까, 'npm run dev' 로 실행하십쇼. "
<br>

#### 🎨 제작자 및 제작에 도움을 주신분들

| 제작자 | 디자인 | client | server | database |
|-----|--------|--------|--------|----------|
| <img src="https://github.com/user-attachments/assets/f903df15-00be-4558-ab20-ca3354d379bc" alt="대표" width="130" height="170"> | <img src="https://github.com/user-attachments/assets/ff42ca7a-01b4-4518-9369-d768d1e3f3f1" alt="디자인" width="130" height="130" align="center"> | <img src="https://github.com/user-attachments/assets/790f7a1d-466f-4893-bf12-e55a40904087" alt="client" width="130" height="140"> | <img src="https://github.com/user-attachments/assets/790f7a1d-466f-4893-bf12-e55a40904087" alt="server" width="130" height="140"> | <img src="www.vuejs.org" alt="database" width="130" height="140"> 
| 나 | vuetify 공식문서 | Vue 3.5  | Express  | MySQL;

#### 💡 아주 도움을 많이 주신 분들입니다.


## ERD

#### 추후 추가 예정.

##Link



## Project Setup

```sh
npm install
```

### Compile and Hot-Reload for Development

```sh
npm run dev
```

#### ‼️ 위에서도 설명했지만 'npm run dev' 다. 누군지 굳이 언급 안하겠지만 나한테 "우웅 pull 했는데 왜 안되징...?" 하던애 때문에 강조한다. 

### Compile and Minify for Production

```sh
npm run build
```

### Lint with [ESLint](https://eslint.org/)

```sh
npm run lint
esLint 썻다 참고해라.
```
